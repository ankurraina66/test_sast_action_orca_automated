# AppScan MCP Server

A Model Context Protocol (MCP) server that integrates with HCL AppScan API, enabling GitHub Copilot and other MCP clients to interact with AppScan's application security testing platform.

## Quick Start for Users

**New to this server?** Check out the [**User Guide**](USER_GUIDE.md) for step-by-step installation and usage instructions.

## Features

This MCP server provides tools to:

### Authentication
- Direct API key authentication via the `X-Api-Key` header on every request

### Account & Tenant Management
- **get-tenant-info**: Get organization and subscription information

### Application Management
- **get-apps**: List all applications with optional filtering
- **create-app**: Create new applications

### Scan Management
- **get-scans**: List all security scans with optional filtering
- **create-scan**: Create or start an AppScan SAST scan for a local project, or create an SCA scan when requested, with **intelligent project-aware configuration**
  - Automatically detects project type (Java, .NET, C++, Node.js, Python, PHP)
  - Auto-configures build settings, classpaths, and compilers
  - Smart exclusions for test files, build outputs, and third-party code
  - See [CONFIGURATION_GUIDE.md](CONFIGURATION_GUIDE.md) for details

### Issue Management
- **get-issues**: List security issues for an application (provide application ID)
- **get-scan-issues**: List security issues for a specific scan (provide scan ID)
- **get-issue-details**: Get detailed information about specific issues
- **update-issues**: Update status/comments for filtered issues in a scope (PUT /api/v4/Issues/{scope}/{scopeId})

### Reporting
- **get-reports**: List generated reports
- **create-security-report**: Create security reports in PDF, HTML, or XML format

### Asset Organization
- **get-asset-groups**: List asset groups (organizational units)

## Installation

### Option 1: Install from NPM (Recommended)

Once published, users can install globally:
```bash
npm install -g mcp-appscan-server
```

Or use directly with npx (no installation needed):
```bash
npx mcp-appscan-server
```

### Option 2: Install from Source

1. Clone this repository:
```bash
git clone https://github.com/yourusername/mcp-appscan-server.git
cd mcp-appscan-server
```

2. Install dependencies:
```bash
npm install
```

3. Build the project:
```bash
npm run build
```

## Configuration

### For VS Code / GitHub Copilot

You have two options for configuration:

#### Option 1: Global Configuration (Recommended - works in all projects)

Add to your **VS Code User Settings** (`settings.json`):
1. Open Command Palette (Ctrl+Shift+P / Cmd+Shift+P)
2. Type "Preferences: Open User Settings (JSON)"
3. Add this configuration:

```json
{
  "github.copilot.chat.mcp.servers": {
    "appscan": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

This configuration will be available in **all your projects**.

#### Option 2: Project-Specific Configuration

Add to your `.vscode/mcp.json` (create it in your workspace):

**If installed from NPM:**
```json
{
  "servers": {
    "appscan": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**If running from source:**
```json
{
  "servers": {
    "appscan": {
      "type": "stdio",
      "command": "node",
      "args": ["c:\\projects\\MCP\\build\\index.js"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**Important**: Replace `your-api-key-id-here` and `your-api-key-secret-here` with your actual AppScan API credentials.

### For Claude Desktop

Add to your Claude Desktop configuration file:

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Linux**: `~/.config/Claude/claude_desktop_config.json`

**If installed from NPM:**
```json
{
  "mcpServers": {
    "appscan": {
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**If running from source:**
```json
{
  "mcpServers": {
    "appscan": {
      "command": "node",
      "args": ["c:\\projects\\MCP\\build\\index.js"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**Important**: Replace `your-api-key-id-here` and `your-api-key-secret-here` with your actual AppScan API credentials.

## Usage Examples

Once configured with your credentials, you can interact with AppScan through GitHub Copilot or Claude Desktop:

### Getting Organization Info
```
Show me information about my AppScan organization
```

### Managing Applications
```
List all my AppScan applications
```

```
Create a new application called "MyWebApp" in AppScan
```

### Managing Scans
```
Show me all my security scans
```

```
Can you create a SAST scan in this project?
```

```
Start an AppScan SAST scan for the current workspace using application ID 12345678
```

```
Create an AppScan SCA scan for my Java project at C:\projects\myapp
```

You can also use natural scan requests such as:
```
Create a scan for this project
Run a SAST scan
Scan this workspace with AppScan
Start an SCA dependency scan
```

By default, `create-scan` uses quiet logging to reduce chat/model token usage. Set `detailedLogs` to `true` only when troubleshooting, because detailed build and AppScan command logs can consume significantly more tokens. For the lowest-token flow, use `wait=false` and keep `detailedLogs=false`; then check scan results later with the scan and issue tools.

Generated local scan artifacts are deleted by default after the scan is created, including the timestamped AppScan output folder and generated zip/IRX files. Set `conserveFiles` to `true` when you want to keep those files for logs, troubleshooting, or inspection.

The `create-scan` tool now automatically:
- Detects your project type (Java/Maven/Gradle, .NET, C++, Node.js, Python, PHP)
- Finds JDK installations and build tools
- Configures appropriate classpaths and compiler settings
- Excludes test files, build outputs, and third-party code
- Generates an optimized `appscan-config.xml` file

For advanced configuration options, see [CONFIGURATION_GUIDE.md](CONFIGURATION_GUIDE.md).

### Reviewing Issues
```
Show me all security issues with high severity
```

```
Get details for issue ID issue-456
```

### Generating Reports
```
Create a PDF security report for application ID abc-123 named "Q4 Security Report"
```

## API Documentation

This server implements the HCL AppScan REST API v4. For complete API documentation, visit:
https://help.hcltechsw.com/appscan/ASoC/appscan_api.html

## Environment Variables

- `APPSCAN_API_BASE`: The base URL for the AppScan API (default: https://cloud.appscan.com)
- `APPSCAN_KEY_ID`: Your AppScan API Key ID (required)
- `APPSCAN_KEY_SECRET`: Your AppScan API Key Secret (required)

## Authentication

### Direct API Key Authentication

The server sends your AppScan credentials on every request using the `X-Api-Key` header. Configure your credentials via environment variables in the MCP configuration:

- `APPSCAN_KEY_ID`: Your API Key ID
- `APPSCAN_KEY_SECRET`: Your API Key Secret

With this setup, you never need to expose your credentials in chat, and there is no separate login or token refresh flow to manage.

### Getting Your API Key

To generate an API Key:
1. Log into AppScan on Cloud
2. Navigate to Settings → API Keys
3. Generate a new key and save the Key ID and Secret
4. Add them to your MCP configuration file's `env` section

## Troubleshooting

### 404 Not Found / Server not working in other projects

**Problem**: The MCP server works in the original project but fails with 404 errors in other projects.

**Solution**: You need to configure the MCP server for each project OR use global configuration.

- **Global Setup (Best)**: Add the server configuration to your VS Code **User Settings** (`github.copilot.chat.mcp.servers`) so it works everywhere. See "Global Configuration" section above.
- **Per-Project Setup**: Each project needs a `.vscode/mcp.json` file with the server configuration and environment variables.

The 404 error occurs because the environment variables (`APPSCAN_KEY_ID`, `APPSCAN_KEY_SECRET`) are not being passed to the server when it runs in a different project context.

### Server not appearing in Copilot
- Ensure you've configured the server in either:
  - **User Settings** (global): `settings.json` → `github.copilot.chat.mcp.servers`
  - **Workspace Settings** (project): `.vscode/mcp.json` → `servers`
- Verify the configuration includes the `env` section with your credentials
- Restart VS Code after modifying the configuration
- Check VS Code's Output panel (View → Output → select "MCP") for errors

### Authentication errors
- Verify your `APPSCAN_KEY_ID` and `APPSCAN_KEY_SECRET` are correctly set in the `env` section
- Check that your API Key ID and Secret are valid (no extra spaces)
- Ensure your AppScan subscription is active
- Look for debug logs in VS Code Output panel showing if credentials are being read

### Connection errors
- Verify the `APPSCAN_API_BASE` URL is correct (default: https://cloud.appscan.com)
- Check your internet connection
- Ensure you have access to the AppScan cloud service
- Check if your organization uses a custom AppScan instance URL

## Development

To modify the server:

1. Edit `src/index.ts`
2. Rebuild: `npm run build`
3. Restart your MCP client (VS Code or Claude Desktop)

## Publishing

See [PUBLISHING.md](PUBLISHING.md) for detailed instructions on how to share this server with others via NPM or GitHub.

Quick publish to NPM:
```bash
npm login
npm run build
npm publish
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

See AppScan API License Agreement at https://www.hcltechsw.com/resources/license-agreements

This MCP server code is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
