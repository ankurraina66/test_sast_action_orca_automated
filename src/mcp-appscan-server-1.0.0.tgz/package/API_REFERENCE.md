# AppScan API Reference

This document lists the major API endpoints available in the HCL AppScan REST API v4. The MCP server implements the most commonly used endpoints.

## Currently Implemented in MCP Server

### Account Management

- ✅ `GET /api/v4/Account/TenantInfo` - Get tenant information (get-tenant-info)
- ✅ Local diagnostics - Non-sensitive server configuration (get-server-info)
- `GET /api/v4/Account/Logout` - Logout
- `POST /api/v4/Account/ApiKey` - Generate API Key
- `PUT /api/v4/Account/TenantInfo` - Update tenant info
- `POST /api/v4/Account/InviteUsers` - Invite users to organization

### Applications

- ✅ `GET /api/v4/Apps` - List applications (get-apps)
- ✅ `POST /api/v4/Apps` - Create application (create-app)
- `DELETE /api/v4/Apps` - Delete application
- `PUT /api/v4/Apps` - Update application
- `POST /api/v4/Apps/Reset` - Reset application
- `GET /api/v4/Apps/{appId}/CorrelationGroups` - Get correlation groups
- `POST /api/v4/Apps/ImportFile` - Import from file
- `GET /api/v4/Apps/{appId}/Policies` - Get app policies
- `POST /api/v4/Apps/{appId}/Policies` - Attach policy
- `PUT /api/v4/Apps/{appId}/Policies` - Update policy
- `DELETE /api/v4/Apps/{appId}/Policies/{policyId}` - Delete policy association

### Asset Groups

- ✅ `GET /api/v4/AssetGroups` - List asset groups (get-asset-groups)
- `POST /api/v4/AssetGroups` - Create asset group
- `DELETE /api/v4/AssetGroups` - Delete asset group
- `PUT /api/v4/AssetGroups` - Update asset group
- `POST /api/v4/AssetGroups/Move` - Move asset group

### Scans

- ✅ `GET /api/v4/Scans` - List scans (get-scans)
- ✅ `POST /api/v4/Scans/Sast` - Create SAST scan (create-scan with `scanType: "SAST"`)
- ✅ `POST /api/v4/Scans/Sca` - Create SCA scan (create-scan with `scanType: "SCA"`)
- ✅ `POST /api/v4/Scans/Dast` - Create DAST scan (create-scan with `scanType: "DAST"`)
- `POST /api/v4/Scans/Iast` - Create IAST scan
- `PUT /api/v4/Scans` - Update scan
- `DELETE /api/v4/Scans` - Delete scan
- `PUT /api/v4/Scans/Dast` - Update DAST scan
- `GET /api/v4/Scans/Dast/{scanId}` - Get DAST scan
- `POST /api/v4/Scans/{scanId}/PromoteIssues` - Promote issues
- `DELETE /api/v4/Scans/{scanId}/Executions` - Delete scan executions
- `POST /api/v4/Scans/{scanId}/Execute` - Execute scan
- `GET /api/v4/Scans/{scanId}/Executions` - Get scan executions
- `GET /api/v4/Scans/{scanId}/Executions/{executionId}/RawResults` - Get raw results
- `GET /api/v4/Scans/{scanId}/Executions/{executionId}/ExploreDataCounters` - Get explore data
- `GET /api/v4/Scans/{scanId}/Logs` - Get scan logs
- `GET /api/v4/Scans/{scanId}/Executions/{executionId}/Logs/Live` - Get live log
- `GET /api/v4/Scans/{scanId}/Executions/{executionId}/Logs/LiveTail` - Get live log tail
- `GET /api/v4/Scans/Dast/{scanId}/File` - Get DAST scan file

Natural-language MCP prompt examples for scan creation:

- `Can you create a SAST scan in this project?`
- `Start an AppScan SAST scan for the current workspace using application ID 12345678.`
- `Create a DAST scan against https://your-app.example.com using application ID 12345678.`

### Issues

- ✅ `GET /api/v4/Issues/Application/{appId}` - List application issues (get-issues)
- ✅ `GET /api/v4/Issues/Scan/{scanId}` - List scan issues (get-scan-issues)
- ✅ `GET /api/v4/Issues/{issueId}` - Get issue (get-issue-details)
- ✅ `PUT /api/v4/Issues/Scan/{scanId}` - Update filtered scan issues (update-individual-issue-by-scan)
- ✅ `PUT /api/v4/Issues/Application/{appId}` - Update filtered application issues (update-individual-issue-by-app)
- ✅ `PUT /api/v4/Issues/Application/{appId}` - Update application issues (update-application-issues)
- ✅ `PUT /api/v4/Issues/Scan/{scanId}` - Update scan issues (update-scan-issues)
- `GET /api/v4/Issues/{issueId}/Comments` - Get issue comments
- `GET /api/v4/Issues/{issueId}/Details` - Get issue details
- `GET /api/v4/Issues/{issueId}/History` - Get issue history
- `POST /api/v4/Issues/Import` - Import issues
- `POST /api/v4/Issues/{issueId}/ReplayScript` - Replay script

### Reports

- ✅ `GET /api/v4/Reports` - List reports (get-reports)
- ✅ `POST /api/v4/Reports/Security` - Create security report (create-security-report)
- `GET /api/v4/Reports/{reportId}/Download` - Download report
- `POST /api/v4/Reports/Issues` - Create issues report
- `POST /api/v4/Reports/Regulation` - Create regulation report
- `POST /api/v4/Reports/License` - Create license report
- `POST /api/v4/Reports/Sbom` - Create SBOM report
- `DELETE /api/v4/Reports/{reportId}` - Delete report
- `GET /api/v4/Reports/Article/{articleId}` - Get article

### Policies

- `GET /api/v4/Policies` - List policies
- `POST /api/v4/Policies` - Create policy
- `PUT /api/v4/Policies` - Update policy
- `DELETE /api/v4/Policies/{policyId}` - Delete policy

### Presences (Agents)

- `GET /api/v4/Presences` - List presences
- `POST /api/v4/Presences` - Create presence
- `DELETE /api/v4/Presences/{presenceId}` - Delete presence
- `PUT /api/v4/Presences` - Update presence
- `POST /api/v4/Presences/{presenceId}/GenerateNewKey` - Generate new key
- `GET /api/v4/Presences/{presenceId}/Download/{key}` - Download presence

### Business Units

- `GET /api/v4/BusinessUnits` - List business units
- `POST /api/v4/BusinessUnits` - Create business unit
- `PUT /api/v4/BusinessUnits/Merge` - Merge business units
- `DELETE /api/v4/BusinessUnits/{businessUnitId}` - Delete business unit
- `PUT /api/v4/BusinessUnits` - Update business unit

### Domains

- `GET /api/v4/Domains` - List domains
- `PUT /api/v4/Domains` - Update domain
- `DELETE /api/v4/Domains` - Delete multiple domains
- `POST /api/v4/Domains/ResendMail` - Resend verification email
- `GET /api/v4/Domains/{domainId}/DownloadFile` - Download verification file
- `POST /api/v4/Domains/{domainId}/Verify` - Verify domain
- `POST /api/v4/Domains/{domainId}/Confirm` - Confirm domain
- `POST /api/v4/Domains/Register` - Register domain
- `POST /api/v4/Domains/Allow` - Allow domain
- `POST /api/v4/Domains/Block` - Block domain

### Fix Groups

- `GET /api/v4/FixGroups/{scope}/{scopeId}` - List fix groups in scope
- `PUT /api/v4/FixGroups/{scope}/{scopeId}/{fixGroupId}` - Update fix group in scope
- `GET /api/v4/FixGroups/{fixGroupId}/Comments` - Get fix group comments

### Open Source Libraries

- `GET /api/v4/OSLibraries/Licenses` - Get licenses for scope
- `GET /api/v4/OSLibraries/Libraries` - Get libraries for scope
- `GET /api/v4/OSLibraries/OrganizationLibraries` - Get libraries for organization
- `GET /api/v4/OSLibraries/{libraryId}/Apps` - Get apps containing library
- `GET /api/v4/OSLibraries/{libraryId}/Scans` - Get scans containing library
- `GET /api/v4/OSLibraries/LicensesList` - Get licenses list

### Roles

- `GET /api/v4/Roles` - List roles
- `POST /api/v4/Roles` - Create role
- `DELETE /api/v4/Roles/{roleId}` - Delete role
- `PUT /api/v4/Roles` - Update role

### Audits

- `GET /api/v4/Audits` - List audit events
- `GET /api/v4/Audits/{auditId}/AdditionalData` - Get audit additional data

### Organization Settings

- `GET /api/v4/OrgSettings/ReportCustomization` - Get report customization
- `PUT /api/v4/OrgSettings/ReportCustomization` - Update report customization

### File Upload

- `POST /api/v4/FileUpload` - Upload file

## Common OData Query Parameters

Many endpoints support OData query parameters for filtering and pagination:

- `$filter` - Filter results (e.g., `$filter=Name eq 'MyApp'`)
- `$top` - Limit number of results (e.g., `$top=10`)
- `$skip` - Skip number of results (e.g., `$skip=20`)
- `$orderby` - Sort results (e.g., `$orderby=Created desc`)
- `$select` - Select specific fields (e.g., `$select=Id,Name`)

## Response Formats

Most endpoints return JSON with this structure:

- List endpoints: `{ "Items": [...], "Count": n }`
- Single item endpoints: `{ "Id": "...", "Name": "...", ... }`
- Error responses: `{ "Message": "...", "ErrorCode": "..." }`

## Authentication

The MCP server authenticates every AppScan API request with a direct API key header:

```
X-Api-Key: <key_id>:<key_secret>
```

## Rate Limits

Check AppScan documentation for current API rate limits and quotas.
