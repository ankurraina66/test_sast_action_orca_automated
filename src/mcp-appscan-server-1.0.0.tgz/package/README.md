# AppScan MCP Server

A Model Context Protocol (MCP) server that integrates with HCL AppScan API, enabling GitHub Copilot and other MCP clients to interact with AppScan's application security testing platform.

## Quick Start for Users

**New to this server?** Check out the [**User Guide**](USER_GUIDE.md) for step-by-step installation and usage instructions.

## Features

This MCP server provides tools to:

### Authentication

- Direct API key authentication via the `X-Api-Key` header on every request
- **get-server-info**: View non-sensitive runtime configuration and operational limits

### Account & Tenant Management

- **get-tenant-info**: Get organization and subscription information

### Application Management

- **get-apps**: List all applications with optional filtering
- **create-app**: Create new applications

### Scan Management

- **get-scans**: List all security scans with optional filtering
- **create-scan**: Create or start an AppScan SAST/SCA scan for a local project, or a DAST scan for a target URL
  - Automatically detects project type (Java, .NET, C++, Node.js, Python, PHP)
  - Auto-configures build settings, classpaths, and compilers
  - Smart exclusions for test files, build outputs, and third-party code
  - Uses an existing `appscan-config.xml` when supplied, otherwise creates a temporary project-aware configuration for the operation

### Issue Management

- **get-issues**: List security issues for an application (provide application ID)
- **get-scan-issues**: List security issues for a specific scan (provide scan ID)
- **get-fix-groups**: List fix groups for a scope (Application, Scan, or ScanExecution)
- **get-issue-details**: Get detailed information about specific issues
- **update-issues**: Update status/comments for filtered issues in a scope (PUT /api/v4/Issues/{scope}/{scopeId}). Identical repeat calls within 10 minutes are suppressed instead of re-sent; pass `allowDuplicate=true` when the user genuinely wants the same change applied twice. The response reports status transitions only, so a count of `0` alongside a comment still means the write succeeded.
- **update-fix-groups**: Update status/sticky status/comments for a fix group in a scope (PUT /api/v4/FixGroups/{scope}/{scopeId}/{fixGroupId})

### Reporting

- **get-reports**: List, create, and download reports, including Security, Issues, Regulation, License, and SBOM reports

### Asset Organization

- **get-asset-groups**: List asset groups (organizational units)

## Target Selection

The server does not remember application, scan, or scope selections between chat sessions. Within a chat, reuse a target only when the user explicitly established it, and pass its ID to each tool call. If no target is established, ask the user rather than choosing an arbitrary result.

A user-provided name or filter may narrow app or scan discovery. Proceed with a sole match only when the filtered result is complete and its matching total confirms exactly one result. An unfiltered singleton, unknown total, or `top` limit is not proof of uniqueness. Report creation requires an explicit scope and target ID; downloads require an explicit report ID.

When an application name has no match, `get-apps` also returns up to 10 other existing applications, clearly separated from the matching results. For an unresolved scan application, show the actual application names and IDs together with **Create a new application** and **Enter another application name or ID**, then wait for the user's choice. Do not replace the list with a create-only confirmation or infer an application name from the project folder. Creating an application and starting a scan remain separately approved actions.

## Installation

### Option 1: Install from NPM (Recommended)

Once published, users can install globally:

```bash
npm install -g mcp-appscan-server
```

Or use directly with npx (no installation needed):

```bash
npx mcp-appscan-server
```

### Option 2: Install from Source

This option runs the version currently checked out on your computer. It is useful when developing or testing local changes.

Prerequisites:

- Node.js `20.x` through `22.x`
- Git
- AppScan API key ID and secret

1. Clone this repository:

```bash
git clone https://github.com/vinod-pal-hcl/appscan-mcp.git
cd appscan-mcp
```

2. Install dependencies and build the server:

```bash
npm install
npm run build
```

3. Verify that the compiled entry point exists:

```text
build/index.js
```

To run the source-built server directly:

```bash
node build/index.js
```

The server communicates over stdio, so it normally should be started by an MCP client rather than run interactively in a terminal. For a local source checkout, configure the client to use the compiled file:

```json
{
  "servers": {
    "AppScan": {
      "type": "stdio",
      "command": "node",
      "args": ["C:\\projects\\MCP\\build\\index.js"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id",
        "APPSCAN_KEY_SECRET": "your-api-key-secret"
      }
    }
  }
}
```

After changing source files, rebuild and restart the MCP server:

```bash
npm run build
```

For a globally available command that points to this local checkout, run:

```bash
npm install -g .
```

You can then use `mcp-appscan-server` as the MCP command. Run `npm run build` followed by `npm install -g .` whenever you want the global command to include new local changes. Keep API credentials in environment variables or your MCP client's secret storage; do not commit them to the repository.

## Configuration

### Configuring the reports folder

For `get-reports` downloads (`operation: "download"`), the reports directory is selected in this order:

1. The optional tool argument `outputDir`.
2. The server CLI argument `--output-dir <path>`.
3. The environment variable `MYAPP_REPORTS_DIR`.
4. The first MCP workspace root, with a `reports` subfolder, when the client supports roots.
5. `path.join(os.homedir(), "Downloads", "myapp-reports")`.

The default is `~/Downloads/myapp-reports` on macOS/Linux or `%USERPROFILE%\Downloads\myapp-reports` on Windows. The server never uses the working directory as a fallback. Unsupported or unavailable MCP roots are skipped silently.

Set the environment variable in your MCP client configuration (VS Code example; keep your existing AppScan credentials in `env`):

```json
{
  "servers": {
    "AppScan": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "MYAPP_REPORTS_DIR": "~/Downloads/myapp-reports"
      }
    }
  }
}
```

Alternatively, append the CLI option to the server arguments:

```json
"args": ["-y", "mcp-appscan-server", "--output-dir", "~/Downloads/myapp-reports"]
```

Absolute paths are supported, for example `/var/reports/appscan` on macOS/Linux or `C:\\Reports\\AppScan` in Windows JSON. A leading `~` expands to the server user's home directory. Prefer absolute paths or `~` in client configuration: explicitly configured relative CLI/env paths are resolved relative to the launching process, but they are never used as implicit defaults.

When CLI or env configuration sets a base directory, a tool-supplied `outputDir` must stay within it. Relative tool directories are resolved inside that base; CLI takes precedence over env if both are set. Without a configured base, explicit relative tool paths use normal `path.resolve` semantics. Null bytes and escapes such as `../../etc` outside a configured base are rejected. Downloaded filenames are sanitized and the destination folder is created automatically.

`outputDir` replaces the former `outputPath` parameter and accepts a directory, not a filename. Successful downloads return the absolute saved file path; invalid paths and write failures return MCP error results. The selected default source and directory are logged to stderr after the MCP client initializes, never to stdout.

### For VS Code / GitHub Copilot

You have two options for configuration:

#### Option 1: Global Configuration (Recommended - works in all projects)

Add to your **VS Code User Settings** (`settings.json`):

1. Open Command Palette (Ctrl+Shift+P / Cmd+Shift+P)
2. Type "Preferences: Open User Settings (JSON)"
3. Add this configuration:

```json
{
  "github.copilot.chat.mcp.servers": {
    "AppScan": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

This configuration will be available in **all your projects**.

#### Option 2: Project-Specific Configuration

Add to your `.vscode/mcp.json` (create it in your workspace):

**If installed from NPM:**

```json
{
  "servers": {
    "AppScan": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**If running from source:**

```json
{
  "servers": {
    "AppScan": {
      "type": "stdio",
      "command": "node",
      "args": ["c:\\projects\\MCP\\build\\index.js"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**Important**: Replace `your-api-key-id-here` and `your-api-key-secret-here` with your actual AppScan API credentials.

### For Claude Desktop

Add to your Claude Desktop configuration file:

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Linux**: `~/.config/Claude/claude_desktop_config.json`

**If installed from NPM:**

```json
{
  "mcpServers": {
    "AppScan": {
      "command": "npx",
      "args": ["-y", "mcp-appscan-server"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**If running from source:**

```json
{
  "mcpServers": {
    "AppScan": {
      "command": "node",
      "args": ["c:\\projects\\MCP\\build\\index.js"],
      "env": {
        "APPSCAN_API_BASE": "https://cloud.appscan.com",
        "APPSCAN_KEY_ID": "your-api-key-id-here",
        "APPSCAN_KEY_SECRET": "your-api-key-secret-here"
      }
    }
  }
}
```

**Important**: Replace `your-api-key-id-here` and `your-api-key-secret-here` with your actual AppScan API credentials.

## Usage Examples

Once configured with your credentials, you can interact with AppScan through GitHub Copilot or Claude Desktop:

### Getting Organization Info

```
Show me information about my AppScan organization
```

### Managing Applications

```
List all my AppScan applications
```

```
Create a new application called "MyWebApp" in AppScan
```

### Managing Scans

```
Show me all my security scans
```

```
Can you create a SAST scan in this project?
```

```
Start an AppScan SAST scan for the current workspace using application ID 12345678
```

```
Create an AppScan SCA scan for my Java project at C:\projects\myapp
```

```
Create an AppScan DAST scan for https://your-app.example.com using application ID 12345678
```

You can also use natural scan requests such as:

```
Create a scan for this project
Run a SAST scan
Scan this workspace with AppScan
Start an SCA dependency scan
Run a DAST scan for https://your-app.example.com
```

By default, `create-scan` uses quiet logging to reduce chat/model token usage. Users can request retention naturally, for example: "Create the scan and preserve the IRX, configuration, and full troubleshooting logs in C:\\AppScanLogs." The tool maps that request to detailed logging, artifact retention, and the requested working directory. For the lowest-token flow, use `wait=false` and do not request detailed logs; then check scan results later with the scan and issue tools.

Generated local scan artifacts are deleted by default after the scan is created, including the timestamped AppScan output folder and generated zip/IRX files. Natural requests such as "keep the scan files for troubleshooting" or "save the artifacts in C:\\AppScanLogs" cause the tool to retain them and use the requested folder.

The `create-scan` tool now automatically:

- Detects your project type (Java/Maven/Gradle, .NET, C++, Node.js, Python, PHP)
- Finds JDK installations and build tools
- Configures appropriate classpaths and compiler settings
- Applies mode-aware exclusions without excluding required SAST build outputs
- Generates an optimized `appscan-config.xml` file

**SAST never runs a project build command.** Java/.NET build-output scans require prebuilt artifacts; C/C++ requires a supported Visual Studio solution. A developer, CI pipeline, or AI agent with terminal access can run a separately approved build before calling `create-scan`. Build failure or missing artifacts never triggers an automatic source-only fallback. `buildBeforeScan=true` is supported only for SCA, where it retains the existing approved `npm run build` behavior.

SAST `scanMode` follows [HCL's scan-mode guidance](https://help.hcl-software.com/appscan/ASoC/src_scan_modes.html):

| Mode | Behavior |
| --- | --- |
| `auto` (default) | Recursively detects Java/.NET/C++ build-output inputs or other recognized source languages. Mixed compiled/source targets, multiple compiled families, and unrecognized targets stop with guidance rather than guessing. |
| `source-code-only` | Scans original source without requiring a build. For Java/.NET/C++, this is a shallower assessment without build-output dataflow traces. |
| `build-output` | Requires available Java/.NET artifacts and a Visual Studio solution for C/C++; other supported languages still use their source scanners. Does not execute a project build. |

.NET/C++ build-output preparation requires Windows; C/C++ also needs the [supported Visual Studio toolchain](https://help.hcl-software.com/appscan/ASoC/src_client_support.html#src_client_support__plugin_visualstudio). Native executables alone are not .NET bytecode or a C/C++ solution.

SAST keeps `targetDir` as its preparation working directory; it does not substitute a child `build` directory. Prepared-output-only directories use output discovery; source/project directories do not. Existing `appscan-config.xml` in `targetDir` is used unless another `configFile` is explicitly supplied. Supplied configurations are preserved, their explicit `sourceCodeOnly` setting is honored, and conflicting explicit modes or missing explicit files are errors. Relative XML target paths resolve against `targetDir`. Preflight inspects declared target directories conservatively; AppScan remains responsible for applying custom include/exclude rules and validating compiler/dependency compatibility.

Discovery skips dependency/cache directories (such as `node_modules`, `vendor`, `packages`, `.git`, `.gradle`, `.m2`, and virtual environments). Symbolic links or more than 100,000 entries require a narrower real target; discovery is never silently truncated. Artifact checks establish presence, not freshness or completeness: use outputs from the intended revision and make dependencies available. See the [developer language matrix and AI workflow](USER_GUIDE.md#sast-scan-modes-and-build-preparation) for examples.

The default preparation level is `normal`, and secret scanning is enabled by default; set `scanSecrets` to `false` to disable it. Use `scanLevel` and `scanThirdParty` to select the remaining scan scope deliberately. `scanMode` does not change SCA or DAST behavior.

Set `personalScan` to `true` to mark a SAST, SCA, or DAST scan as personal. It defaults to `false`.

### Reviewing Issues

```
Show me all security issues with high severity
```

```
Get details for issue ID issue-456
```

### Managing Fix Groups

```
Show me fix groups for scan 12345678-1234-1234-1234-123456789abc
```

```
Update fix group 3fa85f64-5717-4562-b3fc-2c963f66afa6 in scan 12345678-1234-1234-1234-123456789abc to InProgress with sticky status true and comment "Assigned to platform team"
```

### Tool Argument Examples (MCP Test Clients)

Use these JSON argument payloads when invoking tools directly from an MCP test client or inspector.

**get-fix-groups**

```json
{
  "scope": "Scan",
  "scopeId": "12345678-1234-1234-1234-123456789abc",
  "applyPolicies": "None",
  "top": 25,
  "orderby": "Severity desc",
  "count": true
}
```

**get-fix-groups (policy-selected mode)**

```json
{
  "scope": "Scan",
  "scopeId": "12345678-1234-1234-1234-123456789abc",
  "applyPolicies": "Select",
  "selectPolicyIds": ["11111111-1111-1111-1111-111111111111", "22222222-2222-2222-2222-222222222222"],
  "top": 50,
  "count": true
}
```

**update-fix-groups**

```json
{
  "scope": "Scan",
  "scopeId": "12345678-1234-1234-1234-123456789abc",
  "fixGroupId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "status": "InProgress",
  "stickyStatus": true,
  "comment": "Assigned to platform team",
  "applyPolicies": "None"
}
```

**update-fix-groups (policy-selected mode)**

```json
{
  "scope": "Scan",
  "scopeId": "12345678-1234-1234-1234-123456789abc",
  "fixGroupId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "status": "Fixed",
  "stickyStatus": false,
  "comment": "Closed based on selected policy scope",
  "applyPolicies": "Select",
  "selectPolicyIds": ["11111111-1111-1111-1111-111111111111"]
}
```

### Generating Reports

```
Create a PDF security report for application ID abc-123 named "Q4 Security Report"
```

## API Documentation

This server implements the HCL AppScan REST API v4. For complete API documentation, visit:
https://help.hcltechsw.com/appscan/ASoC/appscan_api.html

## Environment Variables

- `APPSCAN_API_BASE`: The base URL for the AppScan API (default: https://cloud.appscan.com)
- `APPSCAN_KEY_ID`: Your AppScan API Key ID (required)
- `APPSCAN_KEY_SECRET`: Your AppScan API Key Secret (required)
- `APPSCAN_HTTP_TIMEOUT_MS`: Per-request timeout in milliseconds (default: `30000`)
- `APPSCAN_MAX_RETRIES`: Retries for safe read/download requests (default: `2`)
- `APPSCAN_CREATE_SCAN_SKIP_ELICITATION`: Set to exactly `true` to pre-authorize every `create-scan` call for automation, skipping both elicitation and preview/`confirmToken` approval (default: `false`). Other tools are unaffected.
- `LOG_LEVEL`: `debug`, `info`, `warn`, or `error` (default: `info`)

Copy [.env.example](.env.example) as a local reference only. The server does not load `.env` files itself; configure secrets through the MCP client environment and never commit them.

### Unattended Scan Creation

For a trusted automation or CI client, add `"APPSCAN_CREATE_SCAN_SKIP_ELICITATION": "true"` to the AppScan server's `env` configuration and restart the MCP server. This applies to SAST, SCA, and DAST on every `create-scan` call, including clients without elicitation support. No `confirmToken` is needed. Omit the setting or set it to `"false"` to retain interactive approval.

Enabling this setting authorizes the entire scan workflow, including artifact upload, remote scan creation/execution, local cleanup, and an SCA build when `buildBeforeScan=true`. Use it only with trusted callers and intended scan targets. Supply an existing `appId` and all required scan inputs; missing or invalid targets still return errors and no application is automatically selected or created. SAST build/mode validation remains unchanged. Other tools, including `create-app` and issue updates, still require their existing approvals. Automated scan approvals remain in the audit log with `approvalPath: "automation"`.

## Authentication

### Direct API Key Authentication

The server sends your AppScan credentials on every request using the `X-Api-Key` header. Configure your credentials via environment variables in the MCP configuration:

- `APPSCAN_KEY_ID`: Your API Key ID
- `APPSCAN_KEY_SECRET`: Your API Key Secret

With this setup, you never need to expose your credentials in chat, and there is no separate login or token refresh flow to manage.

### Getting Your API Key

To generate an API Key:

1. Log into AppScan on Cloud
2. Navigate to Settings → API Keys
3. Generate a new key and save the Key ID and Secret
4. Add them to your MCP configuration file's `env` section

## Troubleshooting

### 404 Not Found / Server not working in other projects

**Problem**: The MCP server works in the original project but fails with 404 errors in other projects.

**Solution**: You need to configure the MCP server for each project OR use global configuration.

- **Global Setup (Best)**: Add the server configuration to your VS Code **User Settings** (`github.copilot.chat.mcp.servers`) so it works everywhere. See "Global Configuration" section above.
- **Per-Project Setup**: Each project needs a `.vscode/mcp.json` file with the server configuration and environment variables.

The 404 error occurs because the environment variables (`APPSCAN_KEY_ID`, `APPSCAN_KEY_SECRET`) are not being passed to the server when it runs in a different project context.

### Server not appearing in Copilot

- Ensure you've configured the server in either:
  - **User Settings** (global): `settings.json` → `github.copilot.chat.mcp.servers`
  - **Workspace Settings** (project): `.vscode/mcp.json` → `servers`
- Verify the configuration includes the `env` section with your credentials
- Restart VS Code after modifying the configuration
- Check VS Code's Output panel (View → Output → select "MCP") for errors

### Authentication errors

- Verify your `APPSCAN_KEY_ID` and `APPSCAN_KEY_SECRET` are correctly set in the `env` section
- Check that your API Key ID and Secret are valid (no extra spaces)
- Ensure your AppScan subscription is active
- Use `get-server-info` to confirm non-sensitive runtime settings. Credential values are never logged.

### Connection errors

- Verify the `APPSCAN_API_BASE` URL is correct (default: https://cloud.appscan.com)
- Check your internet connection
- Ensure you have access to the AppScan cloud service
- Check if your organization uses a custom AppScan instance URL

### Scan preparation or SAClient failures

- Ensure outbound HTTPS access to the configured AppScan base URL. Configure your system proxy where required.
- SAClientUtil is downloaded into `~/.appscan`; Linux and macOS installations must permit execution from that directory.
- SAClientUtil downloads stream to disk with a default limit of 2048 MiB (2 GiB). Set `APPSCAN_SACLIENT_MAX_DOWNLOAD_MB` to a positive integer in the MCP server's `env` configuration to allow larger trusted downloads, then restart the server. The limit applies to both the reported size and actual bytes received, even when `Content-Length` is absent.
- Stalled SAClientUtil transfers use `APPSCAN_HTTP_TIMEOUT_MS` (default: 30000) as the maximum idle time between chunks. Failed transfers remove the partial ZIP. ZIP extraction still uses an in-memory archive library, so sufficient memory and disk space are required.
- Scan polling is bounded by `maxWaitMinutes` (default: 120). Use `wait=false` to return after scan creation and inspect the scan later.

## Development

To modify the server:

1. Edit `src/index.ts`
2. Rebuild: `npm run build`
3. Restart your MCP client (VS Code or Claude Desktop)

## Publishing

See [PUBLISHING.md](PUBLISHING.md) for detailed instructions on how to share this server with others via NPM or GitHub.

Quick publish to NPM:

```bash
npm login
npm run build
npm publish
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

See AppScan API License Agreement at https://www.hcltechsw.com/resources/license-agreements

This MCP server code is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
